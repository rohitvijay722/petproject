package com.rohit.pet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rohit.pet.entity.Event;
import com.rohit.pet.service.EventService;

@RestController
public class EventController {
	
	@Autowired
	private EventService eventService;
	
	@GetMapping("/getAllEvent")
	public List<Event> getEvent() {
		return eventService.getAllEvent();
	}
	
	@PostMapping("/saveEvent")
	public Event saveEvent(@RequestBody Event event) {
		return eventService.saveEvent(event);
	}

}
