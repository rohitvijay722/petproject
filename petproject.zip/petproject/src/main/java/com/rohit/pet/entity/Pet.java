package com.rohit.pet.entity;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="pet")
public class Pet {
	
	@Id
	@GeneratedValue
	@Column(name="id")
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="owner")
	private String owner;
	
	@Column(name="species")
	private String species;
	
	@Column(name="sex")
	private String sex;
	
	@Column(name="birth")
	private Date birth;
	
	@Column(name="death")
	private Date death;
	
	@OneToMany
	@JoinTable( name = "pet",
    joinColumns = @jakarta.persistence.JoinColumn(name = "pet_id"), 
    inverseJoinColumns = @jakarta.persistence.JoinColumn(name = "id"))
	private List<Event> pet;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getSpecies() {
		return species;
	}

	public void setSpecies(String species) {
		this.species = species;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirth() {
		return birth;
	}

	public void setBirth(Date birth) {
		this.birth = birth;
	}

	public Date getDeath() {
		return death;
	}

	public void setDeath(Date death) {
		this.death = death;
	}

	public List<Event> getPet() {
		return pet;
	}

	public void setPet(List<Event> pet) {
		this.pet = pet;
	}

}
