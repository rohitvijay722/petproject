package com.rohit.pet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rohit.pet.entity.Event;
import com.rohit.pet.repository.EventRepository;

@Service
public class EventService {
	
	@Autowired
	private EventRepository eventRepository;
	
	public List<Event> getAllEvent(){
		return eventRepository.findAll();
	}
	
	public Event saveEvent(Event event) {
		return eventRepository.save(event);
	}

}
