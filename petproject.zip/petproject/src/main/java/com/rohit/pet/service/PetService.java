package com.rohit.pet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rohit.pet.entity.Event;
import com.rohit.pet.entity.Pet;
import com.rohit.pet.repository.EventRepository;
import com.rohit.pet.repository.PetRepository;

@Service
public class PetService {
	
	@Autowired
	private PetRepository petRepository;
	
	@Autowired 
	private EventRepository eventRepository;
	
	public List<Pet> getAllPet(){
		return petRepository.findAll();		
	}
	
	public Pet savePet(Pet pet) {
		return petRepository.save(pet);
	}
	
	public Pet getPetById(int id) {
		return petRepository.getById(id);
	}
	
	public Pet updatePet(int id, Pet pet) {
		Pet p=petRepository.getById(id);
		p.setBirth(pet.getBirth());
		p.setDeath(pet.getDeath());
		p.setName(pet.getName());
		p.setOwner(pet.getOwner());
		p.setSex(pet.getSex());
		p.setSpecies(pet.getSpecies());
		p.setPet(pet.getPet());
		petRepository.deleteById(id);
		return petRepository.save(p);
	}
	
	public Pet saveEvent(int id,Event event) {
		Pet pet=petRepository.getById(id);
		event.setPetId(id);
		eventRepository.save(event);
		return pet;
	}
	
	public Pet deletePet(int id) {
		Pet pet = petRepository.getById(id);
		petRepository.deleteById(id);
		return pet;
	}

}
