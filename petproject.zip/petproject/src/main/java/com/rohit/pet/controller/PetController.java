package com.rohit.pet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rohit.pet.entity.Event;
import com.rohit.pet.entity.Pet;
import com.rohit.pet.service.PetService;

@RestController
public class PetController {
	
	@Autowired
	private PetService petService;
	
	@GetMapping("/getPets")
	public List<Pet> getAllPet(){
		return petService.getAllPet();
	}
	
	@GetMapping("/getPets/{id}")
	public Pet getPetById(@PathVariable int id){
		return petService.getPetById(id);
	}
	
	@PostMapping("/savePet")
	public Pet savePet(@RequestBody Pet pet ) {
		return petService.savePet(pet);
	}
	
	@PutMapping("/updatePet/{id}")
	public Pet updatePet(@PathVariable int id,@RequestBody Pet pet) {
		return petService.updatePet(id,pet);
	}
	
	@PostMapping("/pets/{id}")
	public Pet saveEvent(@PathVariable int id,@RequestBody Event event ) {
		return petService.saveEvent(id,event);
	}
	
	@DeleteMapping("pet/{id}")
	public Pet deletePet(@PathVariable int id) {
		return petService.deletePet(id);
	}

}
